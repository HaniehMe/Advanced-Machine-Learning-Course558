#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Reproduction of: Huang et al., "A soft actor-critic reinforcement learning approach for
over the air active beamforming with reconfigurable intelligent surface",
Physical Communication 66 (2024) 102474.

Pure NumPy + Matplotlib (no PyTorch needed): the SAC agent (V, Q1, Q2, policy networks,
Adam, manual back-propagation) is written from scratch.

Run:   python ris_sac_reproduction.py --mode quick     # minutes on a laptop CPU
       python ris_sac_reproduction.py --mode paper     # long: 40 000 steps per run (Table 1)

Layout of this file (one STEP per block):
  STEP 1  configuration and helper functions
  STEP 2  channel / system model            (paper Sec. 3, Eqs. 1-9)
  STEP 3  baselines: WMMSE and AO           (paper Sec. 5 reference schemes)
  STEP 4  neural-network building blocks    (MLP + Adam, hand-written back-prop)
  STEP 5  soft actor-critic agent           (paper Sec. 4, Eqs. 11-17, Algorithm 1)
  STEP 6  training / evaluation of one case
  STEP 7  schematic figures                 (Fig. 1, 2, 3)
  STEP 8  experiments and result figures    (Fig. 4 ... 9)
"""
import argparse, os, time, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

# =====================================================================================
# STEP 1 - configuration
# =====================================================================================
ap = argparse.ArgumentParser()
ap.add_argument("--mode", default="quick", choices=["quick", "paper"])
ap.add_argument("--out", default="figs")
args, _ = ap.parse_known_args()

if args.mode == "paper":      # values of Table 1 in the paper
    CFG = dict(steps=40000, batch=16, buf=40000, lr=1e-3, tau=1e-3, gamma=1.0, hid=256,
               T=50, n_test=50, warm=1000)
else:                         # reduced budget so that everything finishes quickly on one CPU
    CFG = dict(steps=2500, batch=32, buf=40000, lr=1e-3, tau=1e-2, gamma=0.9, hid=64,
               T=25, n_test=20, warm=300)

WARM_START = True    # episode starts from a heuristic beamformer (see ARISEnv.heuristic_action)
SYS = dict(M=6, K=4, N=30, Pmax_dbm=30.0, R=50.0, L=0.0, sig_e2=0.1, kappa_s=3.0)
os.makedirs(args.out, exist_ok=True)
rng_global = np.random.default_rng(0)


def dbm2lin(x_dbm):
    """power in units of the noise power (-100 dBm  ->  1.0)"""
    return 10.0 ** ((x_dbm + 100.0) / 10.0)


def steer(theta, n):
    """half-wavelength ULA steering vector"""
    return np.exp(1j * np.pi * np.arange(n) * np.sin(theta))


def cn(rng, *shape):
    return (rng.standard_normal(shape) + 1j * rng.standard_normal(shape)) / np.sqrt(2)


# =====================================================================================
# STEP 2 - system model: BS(M ant.) -> active ARIS (N elements) -> K single-antenna users
# =====================================================================================
class ARISEnv:
    """Environment of the paper. One *episode* = one channel realisation, T steps.
    state  s_t : observed channels (G', f_k', h_k), previous action, per-user rates
    action a_t : real/imag of W (M x K) and of the ARIS diagonal Phi (N)   -> 2(MK+N) numbers
    reward r_t : sum-rate  sum_k log2(1+gamma_k)  of Eq. (10), computed with the TRUE channels
    """

    def __init__(s, M, K, N, Pmax_dbm, R, L, sig_e2, kappa_s, csi, T, seed):
        s.M, s.K, s.N, s.csi, s.T = M, K, N, csi, T
        s.sig_e2, s.ks = sig_e2, kappa_s
        s.step_size = 0.001
        s.warm = WARM_START
        P = dbm2lin(Pmax_dbm)
        s.PB, s.PA = 0.99 * P, 0.01 * P          # P_BS^max = 0.99 P, P_ARIS^max = 0.01 P
        s.P = P
        s.rng = np.random.default_rng(seed)
        # ---- geometry (Sec. 5): BS (0,-60,0), user centre (300,0,0), K users in a disc of radius R
        s.bs = np.array([0.0, -60.0, 0.0])
        uc = np.array([300.0, 0.0, 0.0])
        r = R * np.sqrt(s.rng.random(K)); ang = 2 * np.pi * s.rng.random(K)
        s.users = uc + np.stack([r * np.cos(ang), r * np.sin(ang), np.zeros(K)], 1)
        u = (s.bs - uc) / np.linalg.norm(s.bs - uc)          # unit vector user centre -> BS
        s.aris = np.array([uc[0] + L * u[0], uc[1] + L * u[1], 10.0])   # L = horizontal distance
        # ---- large-scale gains
        d_bu = np.linalg.norm(s.users - s.bs, axis=1)
        d_ba = np.linalg.norm(s.aris - s.bs)
        d_au = np.linalg.norm(s.users - s.aris, axis=1)
        s.g_h = 10 ** (-(41.2 + 28.7 * np.log10(d_bu)) / 10)           # weak LoS  PL_w (paper)
        s.g_G = 10 ** (-(35.6 + 22.0 * np.log10(d_ba)) / 10)           # strong links: assumption
        s.g_f = 10 ** (-(35.6 + 22.0 * np.log10(d_au)) / 10)
        # ---- angles used for the LoS parts
        d = s.aris - s.bs
        s.th_bs = np.arctan2(d[1], d[0]) - 0.0
        s.th_G = np.arctan2(d[1], d[0]) + 0.3
        s.th_f = np.arctan2(s.users[:, 1] - s.aris[1], s.users[:, 0] - s.aris[0])
        s.resample()

    # -------- one new realisation of the small-scale fading (and of the CSI error) -------
    def resample(s):
        M, K, N, k, rg = s.M, s.K, s.N, s.ks, s.rng
        LoS = np.sqrt(k / (k + 1)); NLoS = np.sqrt(1 / (k + 1))
        # normalised channels (unit average power per entry)
        s.Gn = LoS * np.outer(steer(s.th_G, N), steer(s.th_bs, M).conj()) + NLoS * cn(rg, N, M)
        s.fn = np.stack([LoS * steer(s.th_f[i], N) + NLoS * cn(rg, N) for i in range(K)])   # K x N
        # Eq. (3) with kappa = 1, both parts Rayleigh
        s.hn = np.sqrt(0.5) * cn(rg, K, M) + np.sqrt(0.5) * cn(rg, K, M)                    # K x M
        s.G = np.sqrt(s.g_G) * s.Gn
        s.f = np.sqrt(s.g_f)[:, None] * s.fn
        s.h = np.sqrt(s.g_h)[:, None] * s.hn
        # observed (possibly imperfect) normalised CSI:  G' = G + E,  f' = f + E_k
        if s.csi == "perfect":
            s.Go, s.fo, s.ho = s.Gn, s.fn, s.hn
        else:
            e = np.sqrt(s.sig_e2)
            s.Go = s.Gn + e * cn(rg, N, M); s.fo = s.fn + e * cn(rg, K, N); s.ho = s.hn
        s.prev_a = s.heuristic_action() if s.warm else np.zeros(2 * (M * K + N), np.float32)
        s.rates = np.zeros(K)

    def heuristic_action(s):
        """Starting point of every episode (only if WARM_START): phases of Phi aligned with the
        observed LoS channels, ZF precoder on the resulting effective channel. Built ONLY from the
        observed (possibly imperfect) CSI. The SAC agent then refines it with its increments."""
        M, K, N = s.M, s.K, s.N
        Go, fo, ho = np.sqrt(s.g_G) * s.Go, np.sqrt(s.g_f)[:, None] * s.fo, np.sqrt(s.g_h)[:, None] * s.ho
        w0 = np.linalg.svd(Go)[2][0].conj()                          # dominant BS beam towards the ARIS
        sv = Go @ w0
        phi = np.exp(-1j * np.angle(sv * fo.conj().sum(0)))           # coherent phase alignment
        phi = phi / np.abs(phi).max()
        W = np.outer(w0, np.ones(K)) * np.sqrt(s.PB / K)
        for _ in range(3):                                           # rescale phi to the ARIS power budget, then ZF
            pw = (np.abs(Go @ W) ** 2).sum(1) + 1.0
            ph = phi * np.sqrt(s.PA / ((np.abs(phi) ** 2 * pw).sum()))
            Hh = ho.conj() + (fo.conj() * ph[None, :]) @ Go
            W = Hh.conj().T @ np.linalg.inv(Hh @ Hh.conj().T)
            W = W / np.linalg.norm(W) * np.sqrt(s.PB)
        W = W / np.abs(W).max(); phi = phi / np.abs(phi).max()
        return np.concatenate([W.real.ravel(), W.imag.ravel(), phi.real, phi.imag]).astype(np.float32)

    # -------- helpers ---------------------------------------------------------------------
    @property
    def sdim(s):   # 2(NM + NK + MK) channels + 2(MK+N) previous action + K rates
        return 2 * (s.N * s.M + s.N * s.K + s.M * s.K) + 2 * (s.M * s.K + s.N) + s.K

    @property
    def adim(s):
        return 2 * (s.M * s.K + s.N)

    def decode(s, a):
        """action in [-1,1] -> (W, phi) that satisfy C1 and C2 with equality"""
        M, K, N = s.M, s.K, s.N
        a = np.asarray(a, np.float64)
        W = (a[:M * K] + 1j * a[M * K:2 * M * K]).reshape(M, K)
        W = W / (np.linalg.norm(W) + 1e-9) * np.sqrt(s.PB)                  # C1:  ||W||^2 = P_BS
        phi = a[2 * M * K:2 * M * K + N] + 1j * a[2 * M * K + N:]
        GW = s.G @ W
        pw = (np.abs(GW) ** 2).sum(1) + 1.0                                  # ||G_i W||^2 + sigma_v^2
        phi = phi * np.sqrt(s.PA / ((np.abs(phi) ** 2 * pw).sum() + 1e-12))  # C2:  P_ARIS = P_A^max
        return W, phi

    def rate(s, W, phi, ris="active"):
        """Eq. (7) + Eq. (10).  ris in {'active','passive','none'}"""
        if ris == "none":
            Hh = s.h.conj(); noise = np.ones(s.K)
        else:
            Hh = s.h.conj() + (s.f.conj() * phi[None, :]) @ s.G
            if ris == "active":      # |f_k^H Phi|^2 sigma_v^2 + (||f_k||^2 + 2) sigma^2
                noise = (np.abs(s.f) ** 2 * np.abs(phi) ** 2).sum(1) + (np.abs(s.f) ** 2).sum(1) + 2
            else:
                noise = np.ones(s.K)
        S = np.abs(Hh @ W) ** 2
        sig = np.diag(S); inter = S.sum(1) - sig
        gam = sig / (inter + noise)
        return np.log2(1 + gam)

    def state(s):
        M, K, N = s.M, s.K, s.N
        parts = [s.Go.real.ravel(), s.Go.imag.ravel(), s.fo.real.ravel(), s.fo.imag.ravel(),
                 s.ho.real.ravel(), s.ho.imag.ravel(), s.prev_a, s.rates / 10.0]
        return np.concatenate(parts).astype(np.float32)

    def reset(s):
        s.resample()
        return s.state()

    def step(s, a):
        # the agent outputs an INCREMENT of the previous beamforming action (iterative refinement
        # inside an episode; the previous action is part of the state, as in the paper)
        raw = np.clip(s.prev_a + s.step_size * np.asarray(a, np.float32), -1, 1)
        W, phi = s.decode(raw)
        rk = s.rate(W, phi)
        s.prev_a = raw.astype(np.float32); s.rates = rk
        return rk.sum(), s.state()


# =====================================================================================
# STEP 3 - reference schemes: WMMSE (no RIS) and alternating optimisation (AO)
# =====================================================================================
def _wmmse_update_W(Hh, c_wt, wt_u, P):
    """closed-form WMMSE precoder with Lagrange multiplier mu found by bisection"""
    Sig = (Hh.conj().T * c_wt) @ Hh                      # sum_k c_k h_k h_k^H
    B = Hh.conj().T * wt_u                               # columns: wt_k u_k h_k
    lam, V = np.linalg.eigh(Sig); lam = np.maximum(lam, 0)
    VB = V.conj().T @ B

    def build(mu):
        return V @ (VB / (lam[:, None] + mu))

    if (np.abs(VB / (lam[:, None] + 1e-30)) ** 2).sum() <= P:
        return build(1e-30)
    lo, hi = 0.0, np.sqrt((np.abs(VB) ** 2).sum() / P) + 1e-12
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        if (np.abs(VB / (lam[:, None] + mid)) ** 2).sum() > P: lo = mid
        else: hi = mid
    return build(hi)


def ao_baseline(env, mode, iters=30, seed=0):
    """mode 'none': WMMSE for the plain MU-MISO;  'passive' / 'active': AO over (W, Phi)
    using the WMMSE reformulation (receive scalars u_k, weights w_k)."""
    rg = np.random.default_rng(seed)
    M, K, N = env.M, env.K, env.N
    Pbs = env.P if mode in ("none", "passive") else env.PB    # other schemes use all the power at the BS
    W = cn(rg, M, K); W *= np.sqrt(Pbs) / np.linalg.norm(W)
    phi = np.exp(1j * 2 * np.pi * rg.random(N))
    if mode == "active":
        pw = (np.abs(env.G @ W) ** 2).sum(1) + 1
        phi = phi * np.sqrt(env.PA / (np.abs(phi) ** 2 * pw).sum())
    best, bestW, bestphi = -1, W, phi
    for it in range(iters):
        Hh = env.h.conj() if mode == "none" else env.h.conj() + (env.f.conj() * phi[None, :]) @ env.G
        noise = np.ones(K) if mode != "active" else \
            (np.abs(env.f) ** 2 * np.abs(phi) ** 2).sum(1) + (np.abs(env.f) ** 2).sum(1) + 2
        S = Hh @ W
        u = np.diag(S) / (np.abs(S) ** 2).sum(1).__add__(noise - np.abs(np.diag(S)) ** 2 + np.abs(np.diag(S)) ** 2 * 0).clip(1e-30) \
            if False else np.diag(S) / ((np.abs(S) ** 2).sum(1) + noise)
        wt = 1.0 / (1.0 - (u.conj() * np.diag(S)).real)
        W = _wmmse_update_W(Hh, wt * np.abs(u) ** 2, wt * u, Pbs)          # (i) update W
        if mode != "none":
            Hh = env.h.conj() + (env.f.conj() * phi[None, :]) @ env.G
            S = Hh @ W
            noise = np.ones(K) if mode != "active" else \
                (np.abs(env.f) ** 2 * np.abs(phi) ** 2).sum(1) + (np.abs(env.f) ** 2).sum(1) + 2
            u = np.diag(S) / ((np.abs(S) ** 2).sum(1) + noise)
            wt = 1.0 / (1.0 - (u.conj() * np.diag(S)).real)
            GW = env.G @ W
            C = env.f.conj()[:, None, :] * GW.T[None, :, :]                   # K x K x N : c_kj
            alpha = env.h.conj() @ W                                           # direct part  K x K
            coef = np.repeat(wt * np.abs(u) ** 2, K)
            Cf = C.reshape(K * K, N)
            A = (Cf.conj().T * coef) @ Cf
            if mode == "active":
                A = A + np.diag(((wt * np.abs(u) ** 2)[:, None] * np.abs(env.f) ** 2).sum(0))
            q = (wt[:, None] * (np.abs(u)[:, None] ** 2 * (alpha.conj()[:, :, None] * C).sum(1)
                                - u.conj()[:, None] * C[np.arange(K), np.arange(K), :])).sum(0)
            if mode == "active":                                               # weighted-ball constraint
                p = (np.abs(GW) ** 2).sum(1) + 1.0
                dsq = 1 / np.sqrt(p)
                Bm = (A * dsq[:, None]) * dsq[None, :]
                lam, V = np.linalg.eigh(Bm); lam = np.maximum(lam, 0)
                rhs = V.conj().T @ (dsq * (-q.conj()))

                def sol(l):
                    return dsq * (V @ (rhs / (lam + l)))

                pw = lambda x: (np.abs(x) ** 2 * p).sum()
                x = sol(1e-30 * lam.mean())
                if pw(x) > env.PA:
                    lo, hi = -12.0, 12.0
                    for _ in range(80):
                        mid = 0.5 * (lo + hi)
                        if pw(sol(lam.mean() * 10 ** mid)) > env.PA: lo = mid
                        else: hi = mid
                    x = sol(lam.mean() * 10 ** hi)
                phi = x
            else:                                                              # unit-modulus: MM steps
                lmax = np.linalg.eigvalsh(A)[-1]
                for _ in range(5):
                    phi = np.exp(1j * np.angle(-(q.conj() + (A - lmax * np.eye(N)) @ phi)))
        r = env.rate(W, phi, mode).sum()
        if r > best: best, bestW, bestphi = r, W.copy(), phi.copy()
    return best


# =====================================================================================
# STEP 4 - neural-network building blocks (ReLU MLP, Adam) with hand-written back-prop
# =====================================================================================
class MLP:
    def __init__(s, sizes, rg, last_scale=1.0):
        s.W, s.b = [], []
        for i in range(len(sizes) - 1):
            lim = np.sqrt(6.0 / (sizes[i] + sizes[i + 1]))
            w = rg.uniform(-lim, lim, (sizes[i], sizes[i + 1]))
            if i == len(sizes) - 2: w *= last_scale
            s.W.append(w.astype(np.float32)); s.b.append(np.zeros(sizes[i + 1], np.float32))

    def params(s): return s.W + s.b

    def forward(s, x):
        hs = [x]
        for i in range(len(s.W)):
            z = hs[-1] @ s.W[i] + s.b[i]
            hs.append(np.maximum(z, 0) if i < len(s.W) - 1 else z)
        return hs[-1], hs

    def backward(s, hs, g):
        n = len(s.W); gW = [None] * n; gb = [None] * n
        for i in reversed(range(n)):
            gW[i] = hs[i].T @ g; gb[i] = g.sum(0)
            g = g @ s.W[i].T
            if i > 0: g = g * (hs[i] > 0)
        return g, gW + gb              # g = gradient w.r.t. the network input


class Adam:
    def __init__(s, params, lr, b1=0.9, b2=0.999):
        s.p, s.lr, s.b1, s.b2, s.t = params, lr, b1, b2, 0
        s.m = [np.zeros_like(p) for p in params]; s.v = [np.zeros_like(p) for p in params]

    def step(s, grads):
        s.t += 1
        for p, g, m, v in zip(s.p, grads, s.m, s.v):
            m *= s.b1; m += (1 - s.b1) * g
            v *= s.b2; v += (1 - s.b2) * g * g
            p -= s.lr * (m / (1 - s.b1 ** s.t)) / (np.sqrt(v / (1 - s.b2 ** s.t)) + 1e-8)


# =====================================================================================
# STEP 5 - soft actor-critic (value network V, target V, twin Q, tanh-Gaussian policy)
# =====================================================================================
class SAC:
    LS_MIN, LS_MAX = -20.0, -0.7                      # "SAC log standard deviation clipping (-20, 2)"
    LS_OFF = -1.5                                      # initial exploration std = exp(-1.5) = 0.22 (implementation choice)

    def __init__(s, sd, ad, hid, lr, gamma, tau, rg):
        s.sd, s.ad, s.gamma, s.tau, s.rg = sd, ad, gamma, tau, rg
        s.pi = MLP([sd, hid, hid, 2 * ad], rg, 0.01)
        s.q1 = MLP([sd + ad, hid, hid, 1], rg); s.q2 = MLP([sd + ad, hid, hid, 1], rg)
        s.v = MLP([sd, hid, hid, 1], rg); s.vt = MLP([sd, hid, hid, 1], rg)
        for p, pt in zip(s.v.params(), s.vt.params()): pt[...] = p
        s.opt = dict(pi=Adam(s.pi.params(), lr), q1=Adam(s.q1.params(), lr),
                     q2=Adam(s.q2.params(), lr), v=Adam(s.v.params(), lr))
        s.log_alpha, s.target_ent, s.lr_alpha = np.log(0.02), -float(ad), 1e-2   # automatic temperature

    def act(s, state, deterministic=False):
        out, _ = s.pi.forward(state[None, :])
        mu, ls = out[0, :s.ad], np.clip(out[0, s.ad:] + s.LS_OFF, s.LS_MIN, s.LS_MAX)
        if deterministic: return np.tanh(mu)
        return np.tanh(mu + np.exp(ls) * s.rg.standard_normal(s.ad)).astype(np.float32)

    def update(s, S, A, R, S2):
        B, ad, sd = len(S), s.ad, s.sd
        alpha = np.exp(s.log_alpha)
        # ---- sample actions from the CURRENT policy (not from the replay buffer) ----------
        out, hp = s.pi.forward(S)
        mu = out[:, :ad]; ls = np.clip(out[:, ad:] + s.LS_OFF, s.LS_MIN, s.LS_MAX); std = np.exp(ls)
        eps = s.rg.standard_normal(mu.shape).astype(np.float32)
        a = np.tanh(mu + std * eps)
        logp = (-0.5 * eps ** 2 - ls - 0.5 * np.log(2 * np.pi) - np.log(1 - a ** 2 + 1e-6)).sum(1)
        qin = np.concatenate([S, a], 1)
        q1o, h1 = s.q1.forward(qin); q2o, h2 = s.q2.forward(qin)
        qmin = np.minimum(q1o[:, 0], q2o[:, 0])
        # ---- (a) value network, Eq. (11)-(12) -----------------------------------------------
        vo, hv = s.v.forward(S)
        gv = (vo[:, 0] - (qmin - alpha * logp))[:, None] / B
        s.opt["v"].step(s.v.backward(hv, gv)[1])
        # ---- (b) Q networks, Eq. (13)-(14) ----------------------------------------------------
        y = R + s.gamma * s.vt.forward(S2)[0][:, 0]
        sa = np.concatenate([S, A], 1)
        for name, net in (("q1", s.q1), ("q2", s.q2)):
            qo, hq = net.forward(sa)
            s.opt[name].step(net.backward(hq, ((qo[:, 0] - y)[:, None] / B).astype(np.float32))[1])
        # ---- (c) policy network, Eq. (15)-(17): reparameterisation trick ----------------------
        m1 = (q1o[:, 0] <= q2o[:, 0]).astype(np.float32)[:, None]
        dQ = s.q1.backward(h1, m1)[0] + s.q2.backward(h2, 1 - m1)[0]
        dQa = dQ[:, sd:]
        r_ = (1 - a ** 2) / (1 - a ** 2 + 1e-6)
        gmu = (alpha * 2 * a * r_ - dQa * (1 - a ** 2)) / B
        gls = (alpha * (-1 + 2 * a * r_ * std * eps) - dQa * (1 - a ** 2) * std * eps) / B
        gls *= ((out[:, ad:] + s.LS_OFF > s.LS_MIN) & (out[:, ad:] + s.LS_OFF < s.LS_MAX))
        s.opt["pi"].step(s.pi.backward(hp, np.concatenate([gmu, gls], 1).astype(np.float32))[1])
        # ---- temperature + soft update of the target value network ----------------------------
        s.log_alpha += s.lr_alpha * alpha * (logp.mean() + s.target_ent)
        s.log_alpha = float(np.clip(s.log_alpha, np.log(1e-4), np.log(1.0)))
        for p, pt in zip(s.v.params(), s.vt.params()): pt += s.tau * (p - pt)


# =====================================================================================
# STEP 6 - Algorithm 1: train one SAC agent, then evaluate it and the baselines
# =====================================================================================
def run_case(N, Pdbm, csi, lr, R, L, steps=None, seed=1, baselines=True, verbose=True):
    steps = steps or CFG["steps"]
    env = ARISEnv(SYS["M"], SYS["K"], N, Pdbm, R, L, SYS["sig_e2"], SYS["kappa_s"], csi, CFG["T"], seed)
    rg = np.random.default_rng(seed + 100)
    agent = SAC(env.sdim, env.adim, CFG["hid"], lr, CFG["gamma"], CFG["tau"], rg)
    nb = min(steps, CFG["buf"])
    bS = np.zeros((nb, env.sdim), np.float32); bS2 = np.zeros_like(bS)
    bA = np.zeros((nb, env.adim), np.float32); bR = np.zeros(nb, np.float32)
    curve = np.zeros(steps); s = env.reset(); t0 = time.time()
    for t in range(steps):
        a = rg.uniform(-1, 1, env.adim).astype(np.float32) if t < CFG["warm"] else agent.act(s)
        r, s2 = env.step(a)
        i = t % nb; bS[i], bA[i], bR[i], bS2[i] = s, a, r / 10.0, s2     # reward scaled by 1/10
        curve[t] = r
        s = env.reset() if (t + 1) % CFG["T"] == 0 else s2
        if t >= CFG["warm"]:
            idx = rg.integers(0, min(t + 1, nb), CFG["batch"])
            agent.update(bS[idx], bA[idx], bR[idx], bS2[idx])
    # ---- evaluation on fresh channel realisations: deterministic policy, last step of episode
    res = dict(sac=[], init=[], ao_act=[], ao_pas=[], none=[])
    for e in range(CFG["n_test"]):
        env.rng = np.random.default_rng(10_000 + e)
        s = env.reset()
        res["init"].append(env.rate(*env.decode(env.prev_a)).sum())   # warm start alone, no learning
        for _ in range(CFG["T"]):
            r, s = env.step(agent.act(s, True))
        res["sac"].append(r)
        if baselines:
            res["ao_act"].append(ao_baseline(env, "active", seed=e))
            env_p = env; Pb = env.P
            res["ao_pas"].append(ao_baseline(env, "passive", seed=e))
            res["none"].append(ao_baseline(env, "none", seed=e))
    out = {k: float(np.mean(v)) for k, v in res.items() if len(v)}
    out["curve"] = curve.tolist()
    if verbose:
        print(f"  N={N:3d} P={Pdbm:4.0f}dBm {csi:9s} lr={lr:g} R={R:g} L={L:g} | "
              + " ".join(f"{k}={v:.2f}" for k, v in out.items() if k != "curve")
              + f" | {time.time() - t0:.0f}s", flush=True)
    return out


_cache = {}
def case(N=30, P=30.0, csi="perfect", lr=None, R=50.0, L=0.0):
    lr = lr or CFG["lr"]
    key = (N, P, csi, lr, R, L)
    if key not in _cache:
        # baselines depend only on the CSI-independent true channels -> compute them once (perfect run)
        _cache[key] = run_case(N, P, csi, lr, R, L, baselines=(csi == "perfect"))
    return _cache[key]


def smooth(x, w=100):
    w = min(w, max(1, len(x) // 10)); k = np.ones(w) / w
    return np.convolve(np.pad(x, (w - 1, 0), mode="edge"), k, mode="valid")


# =====================================================================================
# STEP 7 - schematic figures (paper Fig. 1, 2, 3)
# =====================================================================================
def box(ax, xy, w, h, txt, fc="#fff3b0", fs=8):
    ax.add_patch(FancyBboxPatch(xy, w, h, boxstyle="round,pad=0.02", fc=fc, ec="k", lw=1))
    ax.text(xy[0] + w / 2, xy[1] + h / 2, txt, ha="center", va="center", fontsize=fs)


def fig1():
    fig, ax = plt.subplots(figsize=(7, 4)); ax.axis("off"); ax.set_xlim(0, 10); ax.set_ylim(0, 6)
    box(ax, (0.3, 0.5), 1.4, 0.9, "BS\nM antennas", "#cfe2f3")
    box(ax, (4.2, 4.6), 1.8, 0.9, "ARIS (UAV)\nN active elements", "#d9ead3")
    for i in range(4): box(ax, (7.6 + 0.0, 0.3 + i * 0.55), 1.8, 0.45, f"User {i + 1}" if i < 3 else "User K", "#fce5cd", 7)
    ax.annotate("", (4.2, 4.8), (1.0, 1.4), arrowprops=dict(arrowstyle="->", color="purple", lw=2))
    ax.annotate("", (7.6, 1.2), (6.0, 4.7), arrowprops=dict(arrowstyle="->", color="purple", lw=2))
    ax.annotate("", (7.6, 0.8), (1.7, 0.8), arrowprops=dict(arrowstyle="->", color="red", lw=2, ls="--"))
    ax.text(2.2, 3.4, "G  (BS-ARIS, LoS)", color="purple"); ax.text(6.9, 3.4, "f_k  (ARIS-user, LoS)", color="purple")
    ax.text(3.4, 1.0, "h_k  (BS-user, weak LoS / blocked by trees)", color="red", fontsize=8)
    ax.set_title("Fig. 1  Downlink of the active-ARIS aided MU-MISO system")
    fig.savefig(f"{args.out}/fig1_system.png", dpi=130, bbox_inches="tight"); plt.close(fig)


def fig2():
    fig, ax = plt.subplots(figsize=(10, 4.5)); ax.axis("off"); ax.set_xlim(0, 12); ax.set_ylim(0, 6)
    for x, name, c in [(0.3, "Q network\n(Q1, Q2)", "#d9ead3"), (4.3, "V network\n(V and target V)", "#cfe2f3"),
                       (8.3, "Policy network\n(mean, log std)", "#fce5cd")]:
        box(ax, (x, 0.5), 3.4, 0.7, "Input layer", "#ea9999")
        box(ax, (x, 1.6), 3.4, 0.7, "Hidden layer 1 (ReLU)"); box(ax, (x, 2.7), 3.4, 0.7, "Hidden layer 2 (ReLU)")
        box(ax, (x, 3.8), 3.4, 0.7, "Output layer", "#f6b26b")
        ax.text(x + 1.7, 5.0, name, ha="center", fontsize=10, weight="bold", bbox=dict(fc=c, ec="k"))
        for y in (1.2, 2.3, 3.4): ax.annotate("", (x + 1.7, y + 0.4 - 0.3), (x + 1.7, y), arrowprops=dict(arrowstyle="->"))
    ax.text(1.9, 0.1, "input: (state, sampled action)", ha="center", fontsize=8)
    ax.text(6.0, 0.1, "input: state  ->  V(s)", ha="center", fontsize=8)
    ax.text(10.0, 0.1, "input: state  ->  tanh(Gaussian) action", ha="center", fontsize=8)
    ax.set_title("Fig. 2  DNN structure of the soft actor-critic agent (as implemented here)")
    fig.savefig(f"{args.out}/fig2_network.png", dpi=130, bbox_inches="tight"); plt.close(fig)


def fig3():
    env = ARISEnv(SYS["M"], SYS["K"], 30, 30, 50.0, 0.0, 0.1, 3.0, "perfect", 25, 1)
    fig = plt.figure(figsize=(7, 5)); ax = fig.add_subplot(111, projection="3d")
    ax.scatter(*env.bs, c="b", s=80, marker="^", label="BS (0,-60,0)")
    ax.scatter(*env.aris, c="g", s=80, marker="*", label="ARIS (hovering, z=10 m)")
    ax.scatter(env.users[:, 0], env.users[:, 1], env.users[:, 2], c="orange", s=40, label="K=4 users (R=50 m)")
    for u in env.users:
        ax.plot(*zip(env.aris, u), "g-", lw=1); ax.plot(*zip(env.bs, u), "r--", lw=0.8)
    ax.plot(*zip(env.bs, env.aris), "g-", lw=1)
    ax.set_xlabel("x [m]"); ax.set_ylabel("y [m]"); ax.set_zlabel("z [m]"); ax.legend(fontsize=7)
    ax.set_title("Fig. 3  Simulation scenario (green = strong, red dashed = weak)")
    fig.savefig(f"{args.out}/fig3_scenario.png", dpi=130, bbox_inches="tight"); plt.close(fig)


# =====================================================================================
# STEP 8 - experiments and figures 4-9
# =====================================================================================
def main():
    t0 = time.time(); results = {}
    fig1(); fig2(); fig3()
    C = dict(red="r", blue="b", mag="m", grn="g")

    # ---------------- Fig. 4: learning rate x CSI --------------------------------------------
    print("Fig. 4"); fig, ax = plt.subplots(figsize=(7, 4.5))
    for lr, cs, col in [(1e-3, "perfect", "r"), (1e-3, "imperfect", "b"), (1e-4, "perfect", "m"), (1e-4, "imperfect", "g")]:
        c = np.array(case(30, 30.0, cs, lr)["curve"])
        ax.plot(c, color=col, alpha=0.12); ax.plot(smooth(c), color=col, label=f"{cs.capitalize()} CSI (lr = {lr:g})")
    ax.set_xlabel("Steps"); ax.set_ylabel("Rewards (sum-rate, bps/Hz)"); ax.grid(alpha=.3); ax.legend(fontsize=8)
    ax.set_title("Fig. 4  Rewards vs steps for different learning rates"); fig.savefig(f"{args.out}/fig4_lr.png", dpi=130, bbox_inches="tight"); plt.close(fig)

    # ---------------- Fig. 5: number of ARIS elements ------------------------------------------
    print("Fig. 5"); fig, ax = plt.subplots(figsize=(7, 4.5))
    for N, cs, col in [(4, "perfect", "r"), (4, "imperfect", "m"), (16, "perfect", "b"), (16, "imperfect", "g")]:
        c = np.array(case(N, 30.0, cs)["curve"])
        ax.plot(c, color=col, alpha=0.12); ax.plot(smooth(c), color=col, label=f"N={N} ({cs.capitalize()} CSI)")
    ax.set_xlabel("Steps"); ax.set_ylabel("Rewards"); ax.grid(alpha=.3); ax.legend(fontsize=8)
    ax.set_title("Fig. 5  Rewards vs steps for different numbers of ARIS elements"); fig.savefig(f"{args.out}/fig5_elements_curves.png", dpi=130, bbox_inches="tight"); plt.close(fig)

    # ---------------- Fig. 6: sum-rate vs N ----------------------------------------------------
    print("Fig. 6"); Ns = [10, 30, 50, 70, 90, 110, 130] if args.mode == "paper" else [10, 30, 60, 100]
    rows = {k: [] for k in ["Active ARIS (perfect CSI, SAC)", "Active ARIS (imperfect CSI, SAC)", "Active RIS (perfect CSI, AO)", "Passive RIS (perfect CSI)", "Without RIS (WMMSE)", "Warm start only (no SAC)"]}
    for N in Ns:
        p, i = case(N, 30.0, "perfect"), case(N, 30.0, "imperfect")
        for k, v in zip(rows, [p["sac"], i["sac"], p["ao_act"], p["ao_pas"], p["none"], p["init"]]): rows[k].append(v)
    results["fig6"] = dict(N=Ns, **rows)
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for (k, v), st in zip(rows.items(), ["r-*", "b-v", "m-o", "g-s", "k--", "c:"]): ax.plot(Ns, v, st, label=k, mfc="none")
    ax.set_xlabel("Number of RIS elements N"); ax.set_ylabel("Sum-rate (bps/Hz)"); ax.grid(alpha=.3); ax.legend(fontsize=8)
    ax.set_title("Fig. 6  Sum-rate vs number of ARIS elements"); fig.savefig(f"{args.out}/fig6_sumrate_vs_N.png", dpi=130, bbox_inches="tight"); plt.close(fig)

    # ---------------- Fig. 7: reward curves for two transmit powers ------------------------------
    print("Fig. 7"); fig, ax = plt.subplots(figsize=(7, 4.5))
    for P, cs, col in [(30.0, "perfect", "r"), (30.0, "imperfect", "m"), (50.0, "perfect", "b"), (50.0, "imperfect", "g")]:
        c = np.array(case(30, P, cs)["curve"])
        ax.plot(c, color=col, alpha=0.12); ax.plot(smooth(c), color=col, label=f"P={P:.0f} dBm ({cs.capitalize()} CSI)")
    ax.set_xlabel("Steps"); ax.set_ylabel("Rewards"); ax.grid(alpha=.3); ax.legend(fontsize=8)
    ax.set_title("Fig. 7  Rewards vs steps for different transmit power"); fig.savefig(f"{args.out}/fig7_power_curves.png", dpi=130, bbox_inches="tight"); plt.close(fig)

    # ---------------- Fig. 8: sum-rate vs P_max ---------------------------------------------------
    print("Fig. 8"); Ps = [25, 30, 35, 40, 45, 50, 55] if args.mode == "paper" else [25, 30, 40, 50, 55]
    rows = {k: [] for k in rows}
    for P in Ps:
        p, i = case(30, float(P), "perfect"), case(30, float(P), "imperfect")
        for k, v in zip(rows, [p["sac"], i["sac"], p["ao_act"], p["ao_pas"], p["none"], p["init"]]): rows[k].append(v)
    results["fig8"] = dict(P=Ps, **rows)
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for (k, v), st in zip(rows.items(), ["r-*", "b-v", "m-o", "g-s", "k--", "c:"]): ax.plot(Ps, v, st, label=k, mfc="none")
    ax.set_xlabel("Total transmit power Pmax (dBm)"); ax.set_ylabel("Sum-rate (bps/Hz)"); ax.grid(alpha=.3); ax.legend(fontsize=8)
    ax.set_title("Fig. 8  Sum-rate vs total transmit power"); fig.savefig(f"{args.out}/fig8_sumrate_vs_P.png", dpi=130, bbox_inches="tight"); plt.close(fig)

    # ---------------- Fig. 9: sum-rate vs ARIS position --------------------------------------------
    print("Fig. 9"); Ls = [50, 100, 150, 200, 250] if args.mode == "paper" else [50, 150, 250]
    fig, ax = plt.subplots(figsize=(7, 4.5)); wdt = 0.2; xs = np.arange(len(Ls)); res9 = {}
    for j, (R, cs, col) in enumerate([(50.0, "perfect", "#1f4e9c"), (50.0, "imperfect", "#d9541e"), (5.0, "perfect", "#f2b705"), (5.0, "imperfect", "#7b2d8e")]):
        vals = [case(30, 30.0, cs, None, R, float(L))["sac"] for L in Ls]; res9[f"R={R:g},{cs}"] = vals
        ax.bar(xs + (j - 1.5) * wdt, vals, wdt, color=col, label=f"{cs.capitalize()} CSI (R={R:g})")
    ax.set_xticks(xs); ax.set_xticklabels(Ls); ax.set_xlabel("Distance L between ARIS and user centre (m)"); ax.set_ylabel("Sum-rate (bps/Hz)")
    ax.legend(fontsize=8); ax.grid(axis="y", alpha=.3); ax.set_title("Fig. 9  Sum-rate vs ARIS position")
    results["fig9"] = dict(L=Ls, **res9); fig.savefig(f"{args.out}/fig9_position.png", dpi=130, bbox_inches="tight"); plt.close(fig)

    json.dump(results, open(f"{args.out}/results.json", "w"), indent=1)
    print("\n==================== RESULT SUMMARY ====================")
    for name in ["fig6", "fig8"]:
        d = results[name]; xk = "N" if name == "fig6" else "P"
        print(f"\n{name}  (x = {xk})"); print("  x:", d[xk])
        for k, v in d.items():
            if k != xk: print(f"  {k:36s}", " ".join(f"{x:7.2f}" for x in v))
    print("\nfig9 (L =", results["fig9"]["L"], ")")
    for k, v in results["fig9"].items():
        if k != "L": print(f"  {k:28s}", " ".join(f"{x:7.2f}" for x in v))
    print(f"\ntotal time {time.time() - t0:.0f}s")


if __name__ == "__main__":
    main()
